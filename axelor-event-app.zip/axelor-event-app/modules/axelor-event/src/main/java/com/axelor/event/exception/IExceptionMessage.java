package com.axelor.event.exception;

public interface IExceptionMessage {

	static final String REGISTRATION_DATE_INCORRECT = /*$$(*/
		      "The registration date is incorrect"  /*)*/;
}
